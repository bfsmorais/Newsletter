<?php
/**
 * A configuração de base do WordPress
 *
 * Este ficheiro define os seguintes parâmetros: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, e ABSPATH. Pode obter mais informação
 * visitando {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} no Codex. As definições de MySQL são-lhe fornecidas pelo seu serviço de alojamento.
 *
 * Este ficheiro contém as seguintes configurações:
 *
 * * Configurações de  MySQL
 * * Chaves secretas
 * * Prefixo das tabelas da base de dados
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Definições de MySQL - obtenha estes dados do seu serviço de alojamento** //
/** O nome da base de dados do WordPress */
define('DB_NAME', 'Newsletter');

/** O nome do utilizador de MySQL */
define('DB_USER', 'root');

/** A password do utilizador de MySQL  */
define('DB_PASSWORD', 'l1nux1ng*');

/** O nome do serviddor de  MySQL  */
define('DB_HOST', 'localhost');

/** O "Database Charset" a usar na criação das tabelas. */
define('DB_CHARSET', 'utf8mb4');

/** O "Database Collate type". Se tem dúvidas não mude. */
define('DB_COLLATE', '');

/**#@+
 * Chaves únicas de autenticação.
 *
 * Mude para frases únicas e diferentes!
 * Pode gerar frases automáticamente em {@link https://api.wordpress.org/secret-key/1.1/salt/ Serviço de chaves secretas de WordPress.org}
 * Pode mudar estes valores em qualquer altura para invalidar todos os cookies existentes o que terá como resultado obrigar todos os utilizadores a voltarem a fazer login
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'aHjaA28n:b |%YMH,Kb*) uN4%4d=$[ilpCCF8Vr%:Aj<LA(JEv)H!eH!CI1{:)S');
define('SECURE_AUTH_KEY',  'x=E7V?dfP,+uvx20dUDm>SygU7$o9yAi+^]}WRLNOrUr.:|#8V[z131Ub9)<6+D]');
define('LOGGED_IN_KEY',    '+8~OXF`b5H9_We%TXDEaZj}3P^t=V!wO}_ixw$=^$[l[{L9wiOyDjZEvWcGIG|%e');
define('NONCE_KEY',        'ziq^$S{$hwN|&U2|wtycQGT(Rk(.>Jz;g#l2p,~g[-e`x=1?RK 5DT:3j!WxXMgB');
define('AUTH_SALT',        ']83bi=h@h[U=O*i/<_vw*<2cRV~m~BzSrpJ|=kyXE4)Q@]6lC96R)~ixbmmQ$bv0');
define('SECURE_AUTH_SALT', 'e(1#|t1~ B5Uui*QE^x@UY6nL.={GG?rN6fyN-9nRK9vjvo!II#4lXu,^]EW!$<T');
define('LOGGED_IN_SALT',   'Bq=~^pG};HZ;Tv.A`>Gphk4}D|cSw<$X9_!FC,:|{^fO+rORuFl H0]dCA3N|6r`');
define('NONCE_SALT',       ']KkA51Ld`c%figoK#Y5S2jb9{i1|$k[u!?$2]4zL(?1sB1n+a?1T{E>c(qG8c50!');

/**#@-*/

/**
 * Prefixo das tabelas de WordPress.
 *
 * Pode suportar múltiplas instalações numa só base de dados, ao dar a cada
 * instalação um prefixo único. Só algarismos, letras e underscores, por favor!
 */
$table_prefix  = 'nwl_';

/**
 * Para developers: WordPress em modo debugging.
 *
 * Mude isto para true para mostrar avisos enquanto estiver a testar.
 * É vivamente recomendado aos autores de temas e plugins usarem WP_DEBUG
 * no seu ambiente de desenvolvimento.
 *
 * Para mais informações sobre outras constantes que pode usar para debugging,
 * visite o Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* E é tudo. Pare de editar! */

/** Caminho absoluto para a pasta do WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Define as variáveis do WordPress e ficheiros a incluir. */
require_once(ABSPATH . 'wp-settings.php');
